import { useState } from "react";
import { auditCostLoadingXer } from "../utils/costLoadingXer.js";
import "./CostLoadingIntelligence.css";
const usd = n => new Intl.NumberFormat("en-US",{style:"currency",currency:"USD"}).format(n);
export default function CostLoadingIntelligence({projectName}) {
  const [audit,setAudit] = useState(null);
  const [filename,setFilename] = useState("");
  const [error,setError] = useState("");
  const [search,setSearch] = useState("");
  const [group,setGroup] = useState("activity");
  async function loadFile(e) {
    const file=e.target.files?.[0]; if (!file) return;
    setError(""); setAudit(null); setFilename(file.name);
    try { if (!file.name.toLowerCase().endsWith(".xer")) throw new Error("Choose a P6 .xer file.");
      const parsed=auditCostLoadingXer(await file.text());
      if (!parsed.activityCount) throw new Error("No TASK activities were found in this XER.");
      setAudit(parsed);
    } catch (err) {setError(err.message || "Unable to parse XER.");}
  }
  const rows = group === "wbs" ? audit?.wbs : audit?.activities;
  const filtered = (rows || []).filter(r=>`${r.activityId || ""} ${r.name || ""} ${r.wbs || ""}`.toLowerCase().includes(search.toLowerCase()));
  return <section className="cli-page">
    <h2>Cost Loading Intelligence</h2>
    <p>Phase 1 — Read-only XER cost audit. No schedule or resource assignments will be changed.</p>
    <div className="cli-panel"><strong>Project: {projectName || "Selected project"}</strong><p>Upload a Primavera P6 XER to inspect existing activity-level cost assignments.</p><input type="file" accept=".xer" onChange={loadFile}/>{filename && <p>File: {filename}</p>}{error && <p role="alert" className="cli-error">{error}</p>}</div>
    {audit && <>
      <div className="cli-metrics">{[["Activities",audit.activityCount],["Resource assignments",audit.assignmentCount],["Activities without assignments",audit.unassignedCount],["Budgeted cost",usd(audit.totals.budget)],["Actual cost (XER fields)",usd(audit.totals.actual)],["Remaining cost",usd(audit.totals.remaining)]].map(([k,v])=><div className="cli-metric" key={k}><small>{k}</small><strong>{v}</strong></div>)}</div>
      <div className="cli-panel"><h3>Resource dictionary</h3><p>{audit.resources.length} resources found. {audit.resources.filter(r=>r.code === "MCGSTANDCOSTONLY").length ? "McGough standard cost resource detected." : "McGough standard cost resource not detected."}</p><div className="cli-resource-list">{audit.resources.map(r=><span key={r.id}>{r.code || r.id} ({r.type})</span>)}</div></div>
      <div className="cli-panel"><div className="cli-toolbar"><h3>Existing cost loading</h3><select aria-label="Group audit" value={group} onChange={e=>setGroup(e.target.value)}><option value="activity">By activity</option><option value="wbs">By WBS</option></select><input aria-label="Filter cost audit" placeholder="Search activities or WBS" value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="cli-table-wrap"><table><thead><tr>{group === "activity" ? <><th>Activity ID</th><th>Activity</th><th>WBS</th><th>Assignments</th></> : <><th>WBS</th><th>Activities</th></>}<th>Budgeted cost</th>{group === "activity" && <><th>Actual cost</th><th>Remaining cost</th></>}</tr></thead><tbody>{filtered.slice(0,500).map((r,i)=><tr key={r.taskId || `${r.wbs}-${i}`}>{group === "activity" ? <><td>{r.activityId}</td><td>{r.name}</td><td>{r.wbs}</td><td>{r.assignments}</td></> : <><td>{r.wbs}</td><td>{r.count}</td></>}<td>{usd(r.budget)}</td>{group === "activity" && <><td>{usd(r.actual)}</td><td>{usd(r.remaining)}</td></>}</tr>)}</tbody></table></div><p className="cli-footnote">Showing {Math.min(500,filtered.length)} of {filtered.length} matching records. This is an audit only; cost matching, Excel approval, and XER writing follow in later patches.</p></div>
    </>}
  </section>;
}
