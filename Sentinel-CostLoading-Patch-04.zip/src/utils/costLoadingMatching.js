import * as XLSX from "xlsx";

const normalize = value => String(value ?? "").toLowerCase().replace(/[^a-z0-9]+/g," ").trim();
const tokens = value => new Set(normalize(value).split(" ").filter(x=>x.length>2 && !["the","and","for","with","building","work","install","installation","submittal","review","approval","fabrication"].includes(x)));
const numeric = value => {const n=Number(value);return Number.isFinite(n)?n:null;};
const columns = ["Source Sheet","Source Row","Estimate Scope","Subcontractor","Reference Amount (NOT APPROVED)","Suggested Activity ID","Suggested Activity Name","Suggested WBS","Match Confidence","Match Score","Match Explanation","Approved CLIN (USER)","Approved Activity ID (USER)","Approved Allocation $ (USER)","Approval Status (USER)","Notes (USER)"];
function sourceRows(sheet) {
  if (!sheet) return [];
  if (sheet.name === "Subcontractor Summary") return sheet.rows.slice(1).map((r,i)=>({key:`${sheet.name}-${i+2}`,row:i+2,description:String(r[0]||"").trim(),subcontractor:String(r[1]||r[2]||"").trim(),referenceAmount:numeric(r[6])})).filter(x=>x.description && x.referenceAmount!==null && x.referenceAmount!==0 && !/total|subtotal/i.test(x.description));
  if (sheet.name === "Summary of All CLINs") return sheet.rows.slice(2).map((r,i)=>({key:`${sheet.name}-${i+3}`,row:i+3,description:String(r[1]||"").trim(),subcontractor:"",referenceAmount:numeric(r[7])})).filter(x=>x.description && x.referenceAmount!==null && x.referenceAmount!==0 && !/total|subtotal/i.test(x.description));
  return [];
}
function bestCandidate(item,activities) {
  const aTokens=tokens(item.description), subTokens=tokens(item.subcontractor);
  const results=[];
  for(const activity of activities) {
    if(activity.activityId.toUpperCase()==="L0E10000" || /construction cost|holding account/i.test(activity.name)) continue;
    const nameTokens=tokens(activity.name), wbsTokens=tokens(activity.wbs);
    let nameHits=0,wbsHits=0,subHits=0;
    for(const t of aTokens){if(nameTokens.has(t)) nameHits++;if(wbsTokens.has(t)) wbsHits++;}
    for(const t of subTokens){if(nameTokens.has(t)||wbsTokens.has(t)) subHits++;}
    const score=nameHits*4+wbsHits*2+Math.min(subHits,2);
    if(score>0)results.push({activity,score,nameHits,wbsHits,subHits});
  }
  results.sort((a,b)=>b.score-a.score || a.activity.activityId.localeCompare(b.activity.activityId));
  return results[0] || null;
}
export function createMatchingReview(audit,estimate,sourceSheet,clins){
  const sheet=estimate.sheets.find(s=>s.name===sourceSheet);
  const items=sourceRows(sheet).map(item=>{
    const best=bestCandidate(item,audit.activities);
    const confidence=!best?"Unmatched":best.score>=12?"Medium":"Low";
    return {...item,candidate:best?.activity||null,confidence,score:best?.score||0,explanation:best?`Name terms: ${best.nameHits}; WBS terms: ${best.wbsHits}; subcontractor terms: ${best.subHits}. Candidate only; human approval required.`:"No meaningful text match; manual activity mapping required."};
  });
  return {sourceSheet,items,matched:items.filter(x=>x.candidate).length,unmatched:items.filter(x=>!x.candidate).length,clins};
}
export function exportMatchingReview(review,audit,clins,estimateFilename){
  if(!review || !review.items.length)throw new Error("Select Subcontractor Summary or Summary of All CLINs with usable scope rows.");
  const wb=XLSX.utils.book_new();
  const data=[columns,...review.items.map(x=>[review.sourceSheet,x.row,x.description,x.subcontractor,x.referenceAmount,x.candidate?.activityId||"",x.candidate?.name||"",x.candidate?.wbs||"",x.confidence,x.score,x.explanation,"","","","Pending",""])];
  const ws=XLSX.utils.aoa_to_sheet(data);ws['!cols']=[20,12,38,24,24,20,44,32,17,12,65,22,24,24,22,35].map(w=>({wch:w}));ws['!autofilter']={ref:`A1:P${data.length}`};
  XLSX.utils.book_append_sheet(wb,ws,"Matching Review");
  const inv=[['Activity ID','Activity Name','WBS','Current Budget','Existing Assignments',...audit.activityCodeTypes.map(t=>t.name)],...audit.activities.map(a=>[a.activityId,a.name,a.wbs,a.budget,a.assignments,...audit.activityCodeTypes.map(t=>a.codes?.[t.id]?.code||"")])];
  XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(inv),"P6 Activity Inventory");
  const award=[['Accepted','CLIN','Description','Award Value'],...clins.map(c=>[c.accepted?'Yes':'No',c.id,c.name,Number(c.amount)||0])];
  XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(award),"Awarded CLIN Register");
  XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([
    ['Sentinel Cost Loading Intelligence — REVIEW ONLY'],
    ['Estimate file',estimateFilename],['Source worksheet',review.sourceSheet],
    ['Source rows',review.items.length],['Candidate matches',review.matched],['Unmatched',review.unmatched],
    ['IMPORTANT','Reference amounts are NOT approved cost loading and may include unawarded CLINs or duplicated totals.'],
    ['IMPORTANT','Review source estimate columns and CLIN allocations before entering approved dollars.'],
    ['IMPORTANT','No amounts are transferred from L0E10000 in this patch. No XER is generated.'],
    ['Workflow','Enter Approved CLIN, Approved Activity ID, Approved Allocation, and Approval Status in Matching Review.'],
    ['Workflow','A later patch will validate totals, exclusions, and source-to-activity relationships before XER export.']
  ]),"Instructions");
  XLSX.writeFile(wb,"Sentinel-Cost-Loading-Matching-Review.xlsx");
}
